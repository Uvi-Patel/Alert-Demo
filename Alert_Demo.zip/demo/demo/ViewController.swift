//
//  ViewController.swift
//  demo
//
//  Created by MAC on 27/05/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var txt11: UITextField!

    @IBOutlet weak var txt1: UITextField!
    
    @IBOutlet weak var txt2: UITextField!
    
    @IBOutlet weak var lb1: UILabel!
    
    @IBAction func btn1(_ sender: Any) {
        lb1.isHidden = false
        var a = Int(txt1.text!)
        var b = Int(txt2.text!)
        var c = a! + b!
        
        lb1.text = String(c)
        print("Sum is \(c)")
        
        if c == 10 {
            self.view.backgroundColor = UIColor.gray
            
            let simplealert = UIAlertController(title: "Hello World", message: "Your Ans is \(c)", preferredStyle: .actionSheet)
            
            let okaction = UIAlertAction(title: "ok", style: .default, handler: nil)
          //  let cancle = UIAlertAction(title: "cancle", style: .default, handler: nil)
            
            simplealert.addAction(okaction)
         //   simplealert.addAction(cancle)
            
            self.present(simplealert, animated: true, completion: nil)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        lb1.isHidden = true
        print("Loaded")
        // Do any additional setup after loading the view.
    }


}

